IFS branding (asset-only)
=========================

Este pacote NÃO sobrescreve seus arquivos. Ele só adiciona a imagem:
  src/assets/ifs-wordmark.svg

Como usar (escolha o que se aplica ao seu projeto):

A) Se você tiver um Navbar.tsx (ex.: src/components/Navbar.tsx)
----------------------------------------------------------------
1) Importe a imagem no topo do arquivo:
   import ifsWordmark from '../assets/ifs-wordmark.svg'

   (ajuste o caminho relativo conforme a sua pasta)

2) No JSX, troque o texto/emoji do título pela imagem, por exemplo:
   <img src={ifsWordmark} alt="Instituto Federal de Sergipe" style={{ height: 28 }} />

B) Se sua navbar está no App.tsx
--------------------------------
1) Importe a imagem no topo:
   import ifsWordmark from './assets/ifs-wordmark.svg'

2) No JSX da <nav>, substitua o texto do título pela imagem:
   <img src={ifsWordmark} alt="Instituto Federal de Sergipe" style={{ height: 28 }} />

C) Opcional: mostrar a marca no Login
-------------------------------------
1) Em src/pages/Login.tsx (ou onde for seu Login), importe:
   import ifsWordmark from '../assets/ifs-wordmark.svg'

2) Renderize acima do título do card:
   <div style={{display:'flex',justifyContent:'center',marginTop:4,marginBottom:12}}>
     <img src={ifsWordmark} alt="Instituto Federal de Sergipe" style={{height:32}} />
   </div>

D) Título/Favicon (opcional)
----------------------------
Em apps/web/index.html:
  <title>IFS Quizzes</title>
  <link rel="icon" type="image/svg+xml" href="/src/assets/ifs-wordmark.svg" />

Observações
----------
- No Docker/Linux, nomes de arquivos são SENSÍVEIS a maiúsculas/minúsculas.
- Não altera rotas, API ou estado. Só imagem e, se você quiser, título do browser.
- Depois de salvar, reinicie só o serviço web: `docker compose restart web`.

Reversão
--------
Basta remover a import e voltar o texto/emoji original da navbar/login.
