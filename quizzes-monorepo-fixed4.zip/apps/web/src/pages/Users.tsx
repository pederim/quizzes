import React, { useEffect, useState } from 'react'
import { api } from '../api'

export default function Users() {
  const [items, setItems] = useState<any[]>([])
  const [form, setForm] = useState({ name: '', email: '', password: '', role: 'ALUNO' })
  const [err, setErr] = useState<string | null>(null)

  async function load() {
    try {
      const data = await api.users.list()
      setItems(data.data)
    } catch (e: any) { setErr(e.message) }
  }

  useEffect(() => { load() }, [])

  async function create() {
    setErr(null)
    try {
      await api.users.create(form)
      setForm({ name: '', email: '', password: '', role: 'ALUNO' })
      load()
    } catch (e: any) { setErr(e.message) }
  }

  async function remove(id: number) {
    if (!confirm('Excluir usuário?')) return
    setErr(null)
    try {
      await api.users.remove(id)
      load()
    } catch (e: any) { setErr(e.message) }
  }

  return (
    <div>
      <h2>Usuários (Admin)</h2>
      {err && <div style={{ color: 'red' }}>{err}</div>}
      <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
        <input placeholder="Nome" value={form.name} onChange={e=>setForm({...form, name:e.target.value})} />
        <input placeholder="Email" value={form.email} onChange={e=>setForm({...form, email:e.target.value})} />
        <input placeholder="Senha" type="password" value={form.password} onChange={e=>setForm({...form, password:e.target.value})} />
        <select value={form.role} onChange={e=>setForm({...form, role:e.target.value})}>
          <option value="ADMIN">ADMIN</option>
          <option value="PROFESSOR">PROFESSOR</option>
          <option value="ALUNO">ALUNO</option>
        </select>
        <button onClick={create}>Criar</button>
      </div>
      <table border={1} cellPadding={6} style={{ borderCollapse: 'collapse' }}>
        <thead><tr><th>ID</th><th>Nome</th><th>Email</th><th>Papel</th><th></th></tr></thead>
        <tbody>
          {items.map((u) => (
            <tr key={u.id}>
              <td>{u.id}</td>
              <td>{u.name}</td>
              <td>{u.email}</td>
              <td>{u.role}</td>
              <td><button onClick={() => remove(u.id)}>Excluir</button></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
