import React, { useEffect, useState } from 'react'
import { api } from '../api'

export default function QuizEdit({ id, onDone }: { id: number | null, onDone: ()=>void }) {
  const isEdit = !!id
  const [form, setForm] = useState({ titulo: '', descricao: '', categoria: '' })
  const [err, setErr] = useState<string | null>(null)

  useEffect(() => {
    (async () => {
      if (!id) return
      try {
        const res = await api.quizzes.get(id)
        setForm({ titulo: res.data.titulo || '', descricao: res.data.descricao || '', categoria: res.data.categoria || '' })
      } catch (e:any) { setErr(e.message) }
    })()
  }, [id])

  async function save() {
    setErr(null)
    try {
      if (isEdit) {
        await api.quizzes.update(id!, form)
      } else {
        await api.quizzes.create(form)
      }
      onDone()
    } catch (e:any) { setErr(e.message) }
  }

  return (
    <div>
      <h2>{isEdit ? 'Editar Quiz' : 'Novo Quiz'}</h2>
      {err && <div style={{ color: 'red' }}>{err}</div>}
      <div style={{ display:'grid', gap: 6, maxWidth: 600 }}>
        <input placeholder="Título" value={form.titulo} onChange={e=>setForm({...form, titulo:e.target.value})} />
        <input placeholder="Descrição" value={form.descricao} onChange={e=>setForm({...form, descricao:e.target.value})} />
        <input placeholder="Categoria" value={form.categoria} onChange={e=>setForm({...form, categoria:e.target.value})} />
        <button onClick={save}>{isEdit ? 'Salvar' : 'Criar'}</button>
      </div>
    </div>
  )
}
