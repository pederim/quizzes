import React, { useEffect, useState } from 'react'
import { api } from '../api'

export default function QuizDetail({ id }: { id: number }) {
  const [quiz, setQuiz] = useState<any | null>(null)
  const [err, setErr] = useState<string | null>(null)
  const [qForm, setQForm] = useState({ enunciado: '', tipo: 'MULTIPLA', opcoes: '', respostaCorreta: '' })

  async function load() {
    try {
      const res = await api.quizzes.get(id)
      setQuiz(res.data)
    } catch (e:any) { setErr(e.message) }
  }

  useEffect(() => { load() }, [id])

  async function addQuestion() {
    setErr(null)
    try {
      const payload: any = {
        quizId: id,
        enunciado: qForm.enunciado,
        tipo: qForm.tipo,
      }
      if (qForm.tipo === 'MULTIPLA') {
        payload.opcoes = { valores: qForm.opcoes.split('|').map(s=>s.trim()) }
        payload.respostaCorreta = { valor: qForm.respostaCorreta }
      } else if (qForm.tipo === 'VF') {
        payload.respostaCorreta = { valor: qForm.respostaCorreta.toLowerCase() === 'true' }
      } else {
        payload.respostaCorreta = { texto: qForm.respostaCorreta }
      }
      await api.questions.create(payload)
      setQForm({ enunciado: '', tipo: 'MULTIPLA', opcoes: '', respostaCorreta: '' })
      load()
    } catch (e:any) { setErr(e.message) }
  }

  async function removeQuestion(qid: number) {
    if (!confirm('Excluir questão?')) return
    try { await api.questions.remove(qid); load() } catch (e:any) { setErr(e.message) }
  }

  if (!quiz) return <p>Carregando...</p>

  return (
    <div>
      <h3>Quiz: {quiz.titulo}</h3>
      {err && <div style={{ color: 'red' }}>{err}</div>}
      <h4>Questões</h4>
      <ul>
        {quiz.questoes.map((q:any) => (
          <li key={q.id}>
            <strong>#{q.id}</strong> {q.enunciado} ({q.tipo})
            <button onClick={()=>removeQuestion(q.id)} style={{ marginLeft: 8 }}>Excluir</button>
          </li>
        ))}
      </ul>

      <h4>Adicionar Questão</h4>
      <div style={{ display:'grid', gap: 6, maxWidth: 600 }}>
        <input placeholder="Enunciado" value={qForm.enunciado} onChange={e=>setQForm({...qForm, enunciado:e.target.value})} />
        <label>Tipo</label>
        <select value={qForm.tipo} onChange={e=>setQForm({...qForm, tipo:e.target.value})}>
          <option value="MULTIPLA">Múltipla</option>
          <option value="VF">Verdadeiro/Falso</option>
          <option value="DISSERTATIVA">Dissertativa</option>
        </select>
        {qForm.tipo === 'MULTIPLA' && (
          <input placeholder="Opções (separe com |)" value={qForm.opcoes} onChange={e=>setQForm({...qForm, opcoes:e.target.value})} />
        )}
        <input placeholder="Resposta correta" value={qForm.respostaCorreta} onChange={e=>setQForm({...qForm, respostaCorreta:e.target.value})} />
        <button onClick={addQuestion}>Adicionar</button>
      </div>
    </div>
  )
}
