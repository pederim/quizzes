import React, { useEffect, useState } from 'react'
import { api } from '../api'

export default function Quizzes({ onView, onEdit, onNew }: { onView: (id:number)=>void, onEdit:(id:number)=>void, onNew:()=>void }) {
  const [items, setItems] = useState<any[]>([])
  const [err, setErr] = useState<string | null>(null)

  async function load() {
    try {
      const res = await api.quizzes.list()
      setItems(res.data)
    } catch (e: any) { setErr(e.message) }
  }

  useEffect(() => { load() }, [])

  async function remove(id: number) {
    if (!confirm('Excluir quiz?')) return
    try { await api.quizzes.remove(id); load() } catch (e:any) { setErr(e.message) }
  }

  async function togglePublish(id: number) {
    try { await api.quizzes.publish(id); load() } catch (e:any) { setErr(e.message) }
  }

  return (
    <div>
      <h2>Quizzes</h2>
      {err && <div style={{ color: 'red' }}>{err}</div>}
      <button onClick={onNew}>Novo Quiz</button>
      <table border={1} cellPadding={6} style={{ borderCollapse: 'collapse', marginTop: 8 }}>
        <thead><tr><th>ID</th><th>Título</th><th>Status</th><th></th></tr></thead>
        <tbody>
          {items.map((q) => (
            <tr key={q.id}>
              <td>{q.id}</td>
              <td>{q.titulo}</td>
              <td>{q.status}</td>
              <td>
                <button onClick={() => onView(q.id)}>Ver</button>{" "}
                <button onClick={() => onEdit(q.id)}>Editar</button>{" "}
                <button onClick={() => togglePublish(q.id)}>{q.status === 'PUBLICADO' ? 'Despublicar' : 'Publicar'}</button>{" "}
                <button onClick={() => remove(q.id)}>Excluir</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
