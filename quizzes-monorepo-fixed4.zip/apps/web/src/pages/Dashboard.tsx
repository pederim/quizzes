import React, { useEffect, useState } from 'react'
import { api } from '../api'

export default function Dashboard() {
  const [count, setCount] = useState<{ quizzes: number, published: number } | null>(null)
  const [err, setErr] = useState<string | null>(null)

  useEffect(() => {
    (async () => {
      try {
        const list = await api.quizzes.list()
        const quizzes = list.data.length
        const published = list.data.filter((q: any) => q.status === 'PUBLICADO').length
        setCount({ quizzes, published })
      } catch (e: any) { setErr(e.message) }
    })()
  }, [])

  return (
    <div>
      <h2>Dashboard</h2>
      {err && <div style={{ color: 'red' }}>{err}</div>}
      {count ? (
        <div style={{ display: 'flex', gap: 16 }}>
          <div style={{ border: '1px solid #ddd', padding: 12, borderRadius: 8 }}>
            <div>Total de Quizzes</div>
            <strong>{count.quizzes}</strong>
          </div>
          <div style={{ border: '1px solid #ddd', padding: 12, borderRadius: 8 }}>
            <div>Publicados</div>
            <strong>{count.published}</strong>
          </div>
        </div>
      ) : (<p>Carregando...</p>)}
    </div>
  )
}
