import React, { useState } from 'react'
import { api } from '../api'

export default function Login({ onLogin }: { onLogin: (data: any) => void }) {
  const [email, setEmail] = useState('admin@demo.com')
  const [password, setPassword] = useState('Admin@123')
  const [err, setErr] = useState<string | null>(null)

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    setErr(null)
    try {
      const data = await api.login(email, password)
      onLogin(data)
    } catch (e: any) {
      setErr(e.message)
    }
  }

  return (
    <div style={{ maxWidth: 360, margin: '10vh auto', border: '1px solid #ddd', padding: 16, borderRadius: 8 }}>
      <h1>Entrar</h1>
      <form onSubmit={submit}>
        <label>Email</label>
        <input value={email} onChange={(e) => setEmail(e.target.value)} style={{ width: '100%', marginBottom: 8 }} />
        <label>Senha</label>
        <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} style={{ width: '100%', marginBottom: 8 }} />
        {err && <div style={{ color: 'red', marginBottom: 8 }}>{err}</div>}
        <button type="submit">Entrar</button>
      </form>
      <p style={{ fontSize: 12, color: '#666', marginTop: 12 }}>Use os logins do seed no README.</p>
    </div>
  )
}
